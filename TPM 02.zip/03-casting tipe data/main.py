# casing adalah cara ubah tipe data variabel

# INTEGER
int("===INTEGER")
data_int = 9
print("data : ", data_int, "type : ", type(data_int))

casting
data_float = float(data_int)
data_str = str(data_int)
data_bool = bool(data_int)
print("data : ", data_float, "type : ", type(data_float))
print("data : ", data_str, "type : ", type(data_str))
print("data : ", data_bool, "type : ", type(data_bool))


# FLOAT
print("===FLOAT===")
float_data = 3.14
print("data : ", float_data, "type : ", type(float_data))

#casting
#ubah jadi int

#ubah jadi str

#ubah jadi bool

#cetak