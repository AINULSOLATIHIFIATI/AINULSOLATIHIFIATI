# input data user
data = input("Masukkan data : ")
print("data = ", data, ", type = ", type(data)

# jika input adalah angka maka casting ke tipe data integer
angka = float(input("Masukkan angka : "))
print("data = ", angka, ", type = ", type(angka))