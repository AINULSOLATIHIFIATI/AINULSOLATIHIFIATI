# integer
# tipe data : bilangan bulat tanpa koma
data_integer = 11
print("data : ", data_integer)
print("tipe data = ", type(data_integer)) 

# float
# tipe data : bilangan desimal, dengan koma
data_float = 3.14
print("data : ", data_float)
print("tipe data = ", type(data_float))

# string
# tipe data : kumpulan karakter
data_string = "universitas pendidikan mandalika"
print("data : ", data_string)
print("tipe data = ", type(data_string))

# boolean
# tipe data : true / false
data_boolean = True
print("data : ", data_boolean)
print("tipe data = ", type(data_boolean))