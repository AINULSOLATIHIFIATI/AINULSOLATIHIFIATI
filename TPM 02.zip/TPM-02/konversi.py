# Suhu dalam Fahrenheit
F = 130

# Menghitung suhu dalam Celsius
C = (F - 32) * 5 / 9

# Menampilkan hasil
print(f"Suhu {F}°F dalam Celsius adalah {C:.2f}°C")