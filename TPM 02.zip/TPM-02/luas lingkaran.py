1import math
2
3# Jari-jari lingkaran
4r = 10
5
6# Menghitung luas lingkaran
7luas = math.pi * (r ** 2)
8
9# Menampilkan hasil
10print(f"Luas lingkaran dengan jari-jari {r} adalah {luas:.2f}")