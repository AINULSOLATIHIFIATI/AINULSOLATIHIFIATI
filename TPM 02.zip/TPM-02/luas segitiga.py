# Memasukkan nilai alas dan tinggi
a = float(input("Masukkan alas segitiga (a): "))
t = float(input("Masukkan tinggi segitiga (t): "))

# Menghitung luas segitiga
luas = 0.5 * a * t

# Menampilkan hasil
print(f"Luas segitiga dengan alas {a} dan tinggi {t} adalah {luas:.2f}")