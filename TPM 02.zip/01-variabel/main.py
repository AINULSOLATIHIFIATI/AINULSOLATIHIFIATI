# variabel adalah wadah yang menampung nilai / data

# cara menaruh nilai / assigment data
a = 10
x = 5
panjang = 1000

# memanggil variabel
print("Nilai a = ",a)
print("Nilai x =" , x)
print("Nilai panjang = " , Panjang)

# penamaan variabel yang benar
nilai_y = 15 # menggunakan underscore
juta10 = 1000000 # angka tidak boleh didepan
nilaiZ = 17,5 # variabel angka dan huruf

# assigment indirect
# memberikan variabel lain
# dari variabel lain

a = 7
print("Nilai a = ", b)

b = a
print("Nilai b = ", b)